package ws

import (
	"encoding/json"
	"letunbackend/db"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

// ViolationMsg — структура сообщения о нарушении зоны для фронта.
type ViolationMsg struct {
	Type      string   `json:"type"` // "zone_violation"
	DroneID   int      `json:"drone_id"`
	Zones     []string `json:"zones"`     // список имён зон
	Timestamp int64    `json:"timestamp"` // UNIX time
}

var (
	upgrader  = websocket.Upgrader{CheckOrigin: func(r *http.Request) bool { return true }}
	Broadcast = make(chan []byte)
	clients   = make(map[*Client]bool)
	clientsMu sync.Mutex
)

type Client struct {
	Conn *websocket.Conn
	Send chan []byte
}

func HandleConnections(w http.ResponseWriter, r *http.Request) {
	ws, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("❌ WebSocket upgrade error: %v", err)
		return
	}
	client := &Client{Conn: ws, Send: make(chan []byte)}
	clientsMu.Lock()
	clients[client] = true
	clientsMu.Unlock()

	go writeMessages(client)

	for {
		_, msg, err := ws.ReadMessage()
		if err != nil {
			clientsMu.Lock()
			delete(clients, client)
			clientsMu.Unlock()
			break
		}

		// Распарсим телеметрию
		var telemetry db.Telemetry
		if err := json.Unmarshal(msg, &telemetry); err == nil && telemetry.Type == "telemetry" {
			log.Printf("📡 [Drone %d] %.6f, %.6f, %dm, %dkm/h",
				telemetry.DroneID,
				telemetry.Latitude,
				telemetry.Longitude,
				telemetry.Altitude,
				telemetry.Speed,
			)

			// Сохраняем в БД
			if err := db.SaveTelemetry(telemetry); err == nil {
				log.Printf("✅ Телеметрия сохранена: drone_id=%d, lat=%.5f, lon=%.5f",
					telemetry.DroneID,
					telemetry.Latitude,
					telemetry.Longitude,
				)
			}

			// Проверяем зоны
			zones, err := db.CheckZoneViolation(telemetry.Longitude, telemetry.Latitude)
			if err != nil {
				log.Printf("❌ CheckZoneViolation error: %v", err)
			}

			// Логим в консоль
			for _, z := range zones {
				log.Printf("🚨 Дрон %d нарушил запретную зону: %s", telemetry.DroneID, z.Name)
			}

			// Если были нарушения — шлём фронту уведомление
			if len(zones) > 0 {
				names := make([]string, len(zones))
				for i, z := range zones {
					names[i] = z.Name
				}
				viol := ViolationMsg{
					Type:      "zone_violation",
					DroneID:   telemetry.DroneID,
					Zones:     names,
					Timestamp: time.Now().Unix(),
				}
				if payload, err := json.Marshal(viol); err != nil {
					log.Printf("❌ Error marshaling violation message: %v", err)
				} else {
					Broadcast <- payload
				}
			}
		}

		// Всегда шлём и «сырое» сообщение (если нужно)
		Broadcast <- msg
	}
}

func HandleBroadcast() {
	for msg := range Broadcast {
		clientsMu.Lock()
		for client := range clients {
			select {
			case client.Send <- msg:
			default:
				close(client.Send)
				delete(clients, client)
			}
		}
		clientsMu.Unlock()
	}
}

func writeMessages(client *Client) {
	for msg := range client.Send {
		if err := client.Conn.WriteMessage(websocket.TextMessage, msg); err != nil {
			client.Conn.Close()
			clientsMu.Lock()
			delete(clients, client)
			clientsMu.Unlock()
			break
		}
	}
}

func HandleCommand(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}
	body := make([]byte, r.ContentLength)
	r.Body.Read(body)
	Broadcast <- body
	w.Write([]byte("OK"))
}
